# =============================================================================
# modules/utils.py
# Fonctions utilitaires : logging, decouverte des PDF, resume.
# =============================================================================

import logging
import sys
from pathlib import Path
from typing import List


def setup_logging(log_level="INFO", log_format=None, log_file=None):
    if log_format is None:
        log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    logger = logging.getLogger("termsheet_extractor")
    logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    logger.handlers.clear()
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(logging.Formatter(log_format))
    logger.addHandler(ch)
    if log_file:
        fh = logging.FileHandler(str(log_file), encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(log_format))
        logger.addHandler(fh)
    return logger


def discover_pdf_files(input_dir: str, allowed_extensions=None) -> List[Path]:
    if allowed_extensions is None:
        allowed_extensions = [".pdf"]
    dir_path = Path(input_dir)
    if not dir_path.exists():
        dir_path.mkdir(parents=True, exist_ok=True)
        return []
    return sorted([
        f for f in dir_path.iterdir()
        if f.is_file() and f.suffix.lower() in allowed_extensions
    ])


def format_summary(records: list) -> str:
    sep = "=" * 60
    lines = ["", sep, "  RESUME DE L'EXTRACTION", sep, "",
             f"  Documents traites : {len(records)}"]
    fields = ["PST_ISIN", "BIL", "CLN", "CAPITAL_PROTECTION",
              "MATURITY", "WORST_OR_AVERAGE", "CURRENCY", "ISSUER"]
    lines.append("")
    lines.append("  Taux de remplissage :")
    lines.append("  " + "-" * 40)
    for field in fields:
        filled = sum(1 for r in records if r.get("values", {}).get(field) is not None)
        rate = (filled / len(records) * 100) if records else 0
        bar = "#" * int(rate / 5) + "." * (20 - int(rate / 5))
        lines.append(f"    {field:<22s} [{bar}] {rate:5.1f}%")
    lines.extend(["", sep])
    return "\n".join(lines)


def save_converted_texts(records: list, output_dir: str):
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    for r in records:
        txt_name = Path(r["source_file"]).stem + ".txt"
        txt_path = Path(output_dir) / txt_name
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(r.get("text", ""))
