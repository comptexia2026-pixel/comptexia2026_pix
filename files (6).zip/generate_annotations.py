# =============================================================================
# generate_annotations.py
# Genere les fichiers JSON d'annotations pour spaCy a partir des PDF.
# Utilise le pipeline (Table + NER + Regex) pour trouver les valeurs,
# puis localise les positions exactes dans le texte pdfminer.
#
# Usage :
#   python generate_annotations.py
#   python generate_annotations.py --input data/input --output data/annotations
#
# Genere un fichier .json par PDF avec le format :
#   { "text": "...", "entities": [[start, end, "LABEL"], ...] }
# =============================================================================

import argparse
import re
import json
import logging
from pathlib import Path

import config
from modules.pdf_extractor import PDFExtractor
from modules.field_extractor import FieldExtractor
from modules.table_extractor import TableExtractor
from modules.ner_extractor import NERExtractor
from modules.utils import setup_logging, discover_pdf_files

logger = logging.getLogger(__name__)

# Labels NER a annoter
ANNOTATION_LABELS = [
    "PST_ISIN", "ISSUER", "CURRENCY", "MATURITY",
    "CAPITAL_PROTECTION", "WORST_OR_AVERAGE",
]


def extract_values_from_pdf(filepath):
    """Extrait les valeurs via le pipeline complet (Table + NER + Regex)."""
    pdf_ext = PDFExtractor(str(filepath))
    text = pdf_ext.extract()
    if not text:
        return None, ""

    # Etape 1 : Tables
    table_ext = TableExtractor(str(filepath), text)
    table_results = table_ext.extract()

    # Etape 2 : NER
    ner_ext = NERExtractor(text)
    ner_issuer = ner_ext.extract_issuer()

    # Etape 3 : Regex
    field_ext = FieldExtractor(
        text=text,
        patterns=config.EXTRACTION_PATTERNS,
        bil_keywords=config.BIL_KEYWORDS,
        known_issuers=config.KNOWN_ISSUERS,
        valid_isin_prefixes=config.VALID_ISIN_PREFIXES,
        valid_currencies=config.VALID_CURRENCIES,
        issuer_false_positives=config.ISSUER_FALSE_POSITIVES,
    )
    regex_results = field_ext.extract_all()

    # Fusion
    final = regex_results["values"]
    if ner_issuer:
        final["ISSUER"] = ner_issuer
    for key, value in table_results.items():
        if value:
            final[key] = value

    return final, text


def find_entity_position(text, label, value):
    """Trouve la position exacte d'une valeur dans le texte.
    Retourne (start, end) ou None."""
    if not value or value in (True, False):
        return None

    value_str = str(value)

    # Cas special : "Open End" -> chercher "no fixed Expiration Date"
    if label == "MATURITY" and value_str == "Open End":
        m = re.search(r"no fixed Expiration Date", text)
        if m:
            return (m.start(), m.end())
        m = re.search(r"no fixed Redemption Date", text)
        if m:
            return (m.start(), m.end())
        m = re.search(r"Open End", text)
        if m:
            return (m.start(), m.end())
        return None

    # Cas special : "Up to X years" -> chercher le pattern
    if label == "MATURITY" and value_str.startswith("Up to"):
        m = re.search(re.escape(value_str), text)
        if m:
            return (m.start(), m.end())
        return None

    # Cas special : CAPITAL_PROTECTION "0" -> chercher "None"
    if label == "CAPITAL_PROTECTION" and value_str == "0":
        m = re.search(r"Capital Protection\s*(?:\(at Expiry\))?\s*:?\s*None", text)
        if m:
            none_pos = m.group(0).rfind("None")
            start = m.start() + none_pos
            return (start, start + 4)
        return None

    # Cas special : WORST_OR_AVERAGE -> chercher le vrai mot-cle
    if label == "WORST_OR_AVERAGE":
        if value_str == "W":
            patterns = [r"\bWO\b", r"(?i)worst[\s\-]?of", r"(?i)worst[\s\-]?performing",
                        r"(?i)linked\s+to\s+worst", r"(?i)lowest\s+performing"]
        else:
            patterns = [r"(?i)\baveraging\b", r"(?i)basket\s+average"]
        for p in patterns:
            m = re.search(p, text[:5000])
            if m:
                return (m.start(), m.end())
        return None

    # Recherche exacte
    pos = text.find(value_str)
    if pos != -1:
        return (pos, pos + len(value_str))

    # Recherche case-insensitive
    m = re.search(re.escape(value_str), text, re.IGNORECASE)
    if m:
        return (m.start(), m.end())

    return None


def generate_annotation(filepath):
    """Genere l'annotation pour un seul PDF."""
    values, text = extract_values_from_pdf(filepath)
    if not values or not text:
        return None

    entities = []
    for label in ANNOTATION_LABELS:
        value = values.get(label)
        if value is None or value == "" or value is False:
            continue

        pos = find_entity_position(text, label, value)
        if pos:
            start, end = pos
            # Verification que le span est correct
            span_text = text[start:end]
            entities.append([start, end, label])
            logger.info(f"  [{start}:{end}] {label} = \"{span_text}\"")
        else:
            logger.warning(f"  {label} = \"{value}\" -> position non trouvee dans le texte")

    return {
        "text": text,
        "entities": entities,
    }


def main():
    parser = argparse.ArgumentParser(description="Generer les annotations spaCy")
    parser.add_argument("--input", "-i", type=str, default=str(config.INPUT_DIR))
    parser.add_argument("--output", "-o", type=str, default=str(config.BASE_DIR / "data" / "annotations"))
    args = parser.parse_args()

    setup_logging("INFO", config.LOG_FORMAT)
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    pdf_files = discover_pdf_files(args.input, config.ALLOWED_EXTENSIONS)
    if not pdf_files:
        print(f"Aucun PDF dans {args.input}")
        return

    print(f"{len(pdf_files)} PDF trouves\n")

    all_annotations = []

    for i, pdf_file in enumerate(pdf_files, 1):
        print(f"[{i}/{len(pdf_files)}] {pdf_file.name}")
        annotation = generate_annotation(pdf_file)

        if annotation:
            # Sauver un JSON par PDF
            json_name = pdf_file.stem + ".json"
            json_path = output_dir / json_name
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(annotation, f, indent=2, ensure_ascii=False)
            print(f"  -> {json_path} ({len(annotation['entities'])} entites)")

            all_annotations.append(annotation)
        else:
            print(f"  -> SKIP (pas de texte)")
        print()

    # Sauver aussi un fichier global
    global_path = output_dir / "all_annotations.json"
    with open(global_path, "w", encoding="utf-8") as f:
        json.dump(all_annotations, f, indent=2, ensure_ascii=False)

    print(f"\n=== {len(all_annotations)} annotations generees dans {output_dir} ===")
    print(f"Fichier global : {global_path}")

    # Stats
    total_entities = sum(len(a["entities"]) for a in all_annotations)
    label_counts = {}
    for a in all_annotations:
        for _, _, label in a["entities"]:
            label_counts[label] = label_counts.get(label, 0) + 1

    print(f"\nTotal entites : {total_entities}")
    for label, count in sorted(label_counts.items()):
        print(f"  {label:22s} : {count}")


if __name__ == "__main__":
    main()
