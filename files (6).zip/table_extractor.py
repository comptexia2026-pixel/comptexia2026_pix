# =============================================================================
# modules/table_extractor.py
# Extraction des champs depuis les tableaux PDF (pdfplumber) et depuis
# le texte avec detection label-valeur (pdfminer).
# C'est l'ETAPE 1 du pipeline. Le field_extractor (regex) est l'ETAPE 2.
# =============================================================================

import re
import logging
from pathlib import Path

import pdfplumber

logger = logging.getLogger(__name__)


# Labels connus et leur champ associe
LABEL_MAP = {
    # ISIN
    "ISIN":                     "PST_ISIN",
    "ISIN code":                "PST_ISIN",
    "ISIN Code":                "PST_ISIN",
    "Code ISIN":                "PST_ISIN",
    "Security Numbers":         "PST_ISIN",
    # Issuer
    "Issuer":                   "ISSUER",
    "Issuer:":                  "ISSUER",
    "Emetteur":                 "ISSUER",
    # Currency
    "Settlement Currency":      "CURRENCY",
    "Specified Currency":       "CURRENCY",
    "Specified Currency:":      "CURRENCY",
    "Redemption Currency":      "CURRENCY",
    # Maturity
    "Maturity Date":            "MATURITY",
    "Maturity Date:":           "MATURITY",
    "Redemption Date":          "MATURITY",
    "Expiration Date":          "MATURITY",
    "Expiration Date:":         "MATURITY",
    "Valuation Date":           "_SKIP_",
    # Capital Protection
    "Capital Protection":       "CAPITAL_PROTECTION",
    "Capital Protection (at Expiry)": "CAPITAL_PROTECTION",
    "Minimum Redemption":       "CAPITAL_PROTECTION",
    # Listing / Governing Law (skip)
    "Governing Law":            "_SKIP_",
    "Listing":                  "_SKIP_",
}

# Valeurs valides pour CURRENCY
VALID_CURRENCIES = {"USD", "EUR", "CHF", "GBP", "JPY", "CAD", "AUD",
                    "SGD", "HKD", "NOK", "SEK", "DKK", "CNY"}


class TableExtractor:

    def __init__(self, pdf_path: str, text: str):
        """
        pdf_path : chemin du PDF (pour pdfplumber)
        text     : texte deja extrait par pdfminer (pour le parsing label-valeur)
        """
        self.pdf_path = pdf_path
        self.text = text

    def extract(self) -> dict:
        """Retourne un dict des champs trouves par tableaux/label-valeur."""
        results = {}

        # Etape 1a : vrais tableaux pdfplumber
        table_results = self._extract_from_pdfplumber_tables()
        results.update(table_results)

        # Etape 1b : parsing label-valeur dans le texte pdfminer
        text_results = self._extract_from_text_labels()
        # Ne pas ecraser ce qui a ete trouve par les tableaux
        for key, value in text_results.items():
            if key not in results or not results[key]:
                results[key] = value

        return results

    # -----------------------------------------------------------------
    # METHODE 1a : Vrais tableaux (pdfplumber)
    # Fonctionne sur : Natixis, UBS, Credit Suisse
    # -----------------------------------------------------------------
    def _extract_from_pdfplumber_tables(self) -> dict:
        results = {}
        try:
            with pdfplumber.open(self.pdf_path) as pdf:
                for page in pdf.pages:
                    tables = page.extract_tables()
                    for table in tables:
                        if not table:
                            continue
                        for row in table:
                            if not row or len(row) < 2:
                                continue
                            label = self._clean_cell(row[0])
                            value = self._clean_cell(row[1])
                            if not label or not value:
                                continue
                            field = self._match_label(label)
                            if field and field != "_SKIP_":
                                parsed = self._parse_value(field, value)
                                if parsed and field not in results:
                                    results[field] = parsed
        except Exception as error:
            logger.debug(f"Erreur extraction tableaux : {error}")
        return results

    # -----------------------------------------------------------------
    # METHODE 1b : Parsing label-valeur dans le texte pdfminer
    # Fonctionne sur : BNP Paribas, tous les PDF avec "Label Valeur"
    # -----------------------------------------------------------------
    def _extract_from_text_labels(self) -> dict:
        results = {}

        for known_label, field in LABEL_MAP.items():
            if field == "_SKIP_":
                continue
            if field in results and results[field]:
                continue

            # IMPORTANT : le label doit etre en debut de ligne (pas en milieu de phrase)
            # Chercher "\nLabel Valeur" ou "^Label Valeur"
            escaped = re.escape(known_label)

            # Pattern 1 : label en debut de ligne suivi de la valeur
            pattern = r"(?:^|\n)\s*" + escaped + r"\s+(.+)"
            for m in re.finditer(pattern, self.text):
                value = m.group(1).strip().split("\n")[0].strip()
                parsed = self._parse_value(field, value)
                if parsed:
                    results[field] = parsed
                    break

            if field in results and results[field]:
                continue

            # Pattern 2 : label en debut de ligne, valeur sur la ligne suivante
            pattern2 = r"(?:^|\n)\s*" + escaped + r"\s*\n\s*(.+)"
            for m in re.finditer(pattern2, self.text):
                value = m.group(1).strip().split("\n")[0].strip()
                parsed = self._parse_value(field, value)
                if parsed:
                    results[field] = parsed
                    break

        return results

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    @staticmethod
    def _clean_cell(cell) -> str:
        if cell is None:
            return ""
        text = str(cell).strip()
        text = re.sub(r"\s+", " ", text)
        return text

    @staticmethod
    def _match_label(label: str) -> str:
        """Trouve le champ correspondant a un label de tableau."""
        # Match exact
        if label in LABEL_MAP:
            return LABEL_MAP[label]
        # Match partiel (le label contient un des mots-cles)
        label_lower = label.lower().strip().rstrip(":")
        for known, field in LABEL_MAP.items():
            known_lower = known.lower().strip().rstrip(":")
            if label_lower == known_lower:
                return field
        # Patterns partiels
        if "isin" in label_lower and "underlying" not in label_lower:
            return "PST_ISIN"
        if label_lower in ("issuer", "emetteur"):
            return "ISSUER"
        if "settlement currency" in label_lower or "specified currency" in label_lower:
            return "CURRENCY"
        if "redemption currency" in label_lower:
            return "CURRENCY"
        if "maturity date" in label_lower:
            return "MATURITY"
        if "expiration date" in label_lower:
            return "MATURITY"
        if "capital protection" in label_lower:
            return "CAPITAL_PROTECTION"
        return ""

    def _parse_value(self, field: str, raw_value: str) -> str:
        """Parse et valide la valeur selon le champ."""
        if not raw_value or len(raw_value) < 1:
            return ""

        value = raw_value.strip()

        if field == "PST_ISIN":
            m = re.search(r"[A-Z]{2}[A-Z0-9]{10}", value)
            return m.group(0) if m else ""

        elif field == "ISSUER":
            # Nettoyer : prendre jusqu'a la virgule ou le saut de ligne
            value = re.split(r"[,\n]", value)[0].strip()
            # Nettoyer les parentheses et guillemets
            value = re.sub(r'\s*\(.*?\)\s*$', '', value).strip()
            value = re.sub(r'\s*".*?"\s*$', '', value).strip()
            # Filtrer les faux positifs
            bad = ["risk", "on the", "an amount", "Exercise", "at maturity",
                   "but to", "which", "along", "right", "has the option",
                   "Guarantor", "Rating", "Supervisory", "/ Warrant",
                   "shall", "will be", "the Issuer", "not subject"]
            if any(b.lower() in value.lower() for b in bad):
                return ""
            if len(value) < 3 or len(value) > 80:
                return ""
            # Doit commencer par une majuscule (nom d'entreprise)
            if not re.match(r"[A-Z]", value):
                return ""
            return value

        elif field == "CURRENCY":
            m = re.search(r"\b([A-Z]{3})\b", value)
            if m and m.group(1) in VALID_CURRENCIES:
                return m.group(1)
            return ""

        elif field == "MATURITY":
            # Open End / no fixed
            if re.search(r"(?i)no\s+fixed|open\s+end", value):
                return "Open End"
            # Date "11 February 2028"
            m = re.search(r"\d{1,2}\s+\w+\s+\d{4}", value)
            if m:
                return m.group(0)
            # Date "16/08/2027"
            m = re.search(r"\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}", value)
            if m:
                return m.group(0)
            return ""

        elif field == "CAPITAL_PROTECTION":
            if value.lower() == "none":
                return "0"
            m = re.search(r"(\d{1,3}(?:[.,]\d+)?)\s*%", value)
            if m:
                return m.group(1)
            return ""

        return value
