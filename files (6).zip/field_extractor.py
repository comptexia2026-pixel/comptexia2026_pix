# =============================================================================
# modules/field_extractor.py
# Extraction des champs metier V3.
# Regex ameliorees pour gerer les sorties pdfminer ou les labels et valeurs
# sont separes par des lignes vides (\n\n) dans les tableaux PDF.
# =============================================================================

import re
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class FieldExtractor:

    def __init__(self, text: str, patterns: dict, bil_keywords: list,
                 known_issuers: list, valid_isin_prefixes: list,
                 valid_currencies: list, issuer_false_positives: list):
        self.text = text
        self.patterns = patterns
        self.bil_keywords = bil_keywords
        self.known_issuers = known_issuers
        self.valid_isin_prefixes = valid_isin_prefixes
        self.valid_currencies = valid_currencies
        self.issuer_false_positives = issuer_false_positives

    def extract_all(self) -> dict:
        all_isins = self._find_real_isins()
        pst_isin, underlying_isins = self._classify_isins(all_isins)

        values = {
            "PST_ISIN": pst_isin,
            "BIL": self._extract_bil(),
            "CLN": self._extract_cln(),
            "CAPITAL_PROTECTION": self._extract_capital_protection(),
            "MATURITY": self._extract_maturity(),
            "WORST_OR_AVERAGE": self._extract_worst_or_average(),
            "CURRENCY": self._extract_currency(),
            "ISSUER": self._extract_issuer(),
        }

        return {"values": values, "underlying_isins": underlying_isins}

    # =========================================================================
    # ISIN avec scoring (INCHANGE)
    # =========================================================================

    def _find_real_isins(self) -> list:
        candidates = re.findall(r"\b([A-Z]{2}[A-Z0-9]{10})\b", self.text)
        real = []
        for c in candidates:
            if c[:2] in self.valid_isin_prefixes and re.search(r"\d", c):
                if c not in real:
                    real.append(c)
        return real

    def _score_isin(self, isin: str) -> int:
        pos = self.text.find(isin)
        if pos == -1:
            return 9999
        score = 9999
        for kw in ["ISIN", "Valor", "Security Number", "ISIN Code",
                    "Code ISIN", "ISIN code", "Security Codes"]:
            for m in re.finditer(re.escape(kw), self.text):
                d = abs(pos - m.start())
                if d < score:
                    score = d
        ctx = self.text[max(0, pos - 150):pos + len(isin) + 150]
        underlying_kws = ["Bloomberg", "Underlying", "RIC:", "Ticker",
                          "Asset Component", "Share"]
        n_underlying = sum(1 for uk in underlying_kws if uk in ctx)
        if n_underlying >= 2:
            score += 800
        return score

    def _classify_isins(self, all_isins: list) -> tuple:
        if not all_isins:
            return None, []
        if len(all_isins) == 1:
            return all_isins[0], []
        scored = [(isin, self._score_isin(isin)) for isin in all_isins]
        scored.sort(key=lambda x: x[1])
        pst = scored[0][0]
        underlyings = [s[0] for s in scored[1:]]
        return pst, underlyings

    # =========================================================================
    # BIL (INCHANGE)
    # =========================================================================

    def _extract_bil(self) -> bool:
        for kw in self.bil_keywords:
            if kw in self.text:
                return True
        for m in re.finditer(r"\bBIL\b", self.text):
            ctx = self.text[max(0, m.start() - 30):m.end() + 30]
            if not any(fp in ctx for fp in ["BILL", "BILLION", "BILLING"]):
                return True
        return False

    # =========================================================================
    # CLN (INCHANGE)
    # =========================================================================

    def _extract_cln(self) -> bool:
        return bool(re.search(r"(?i)\b(credit[\s\-]?linked\s+note|CLN)\b", self.text))

    # =========================================================================
    # CAPITAL PROTECTION - AMELIORE
    # Gere : "Capital Protection (at Expiry)\n\nNone",
    #        "Capital Protection\n\n80%",
    #        "Minimum Redemption 80%",
    #        "No Capital Protection" dans les titres de section
    # =========================================================================

    def _extract_capital_protection(self) -> Optional[float]:
        # Pattern 1 : inline "Capital Protection (at Expiry) None"
        m = re.search(
            r"(?i)Capital\s+Protection\s*(?:\(at\s+Expiry\))?\s*[:\-]?\s*"
            r"(None|\d{1,3}(?:[.,]\d+)?)\s*%?",
            self.text,
        )
        if m:
            val = m.group(1)
            if val.lower() == "none":
                return 0.0
            try:
                return float(val.replace(",", "."))
            except ValueError:
                pass

        # Pattern 2 : pdfminer table "Capital Protection (at Expiry)\n\nNone"
        m = re.search(
            r"(?i)Capital\s+Protection\s*(?:\(at\s+Expiry\))?\s*\n+\s*"
            r"(None|\d{1,3}(?:[.,]\d+)?)\s*%?",
            self.text,
        )
        if m:
            val = m.group(1)
            if val.lower() == "none":
                return 0.0
            try:
                return float(val.replace(",", "."))
            except ValueError:
                pass

        # Pattern 3 : "Minimum Redemption 80%"
        m = re.search(r"(?i)Minimum\s+Redemption\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%", self.text)
        if m:
            return float(m.group(1).replace(",", "."))

        # Pattern 4 : "Protection du Capital : 90%"
        m = re.search(r"(?i)Protection\s+du\s+Capital\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%", self.text)
        if m:
            return float(m.group(1).replace(",", "."))

        # Pattern 5 : "No Capital Protection" comme titre de section = 0%
        if re.search(r"(?i)(?:^|\n)\s*No\s+Capital\s+Protection\s*(?:\n|$)", self.text):
            return 0.0

        # Pattern 6 : "not capital protected at any time" = 0%
        if re.search(r"(?i)not\s+capital\s+protected\s+at\s+any\s+time", self.text):
            return 0.0

        # Pattern 7: "Capital Guarantee: 100%"
        m = re.search(r"(?i)Capital\s+Guarantee\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%", self.text)
        if m:
            return float(m.group(1).replace(",", "."))

        return None

    # =========================================================================
    # MATURITY - AMELIORE
    # Gere : "Maturity Date\n\n04 February 2028" (pdfminer table)
    #        "Maturity Date: \n\n16 August 2027" (Natixis)
    #        "Redemption Date /\nMaturity Date\n\n22 December 2020" (CS)
    #        "no fixed Expiration Date"
    #        "Open End (subject to...)"
    #        "Investment Term Up to 5 years"
    # =========================================================================

    def _extract_maturity(self) -> Optional[str]:
        # Pattern 1 : inline "Maturity Date 04 February 2028"
        m = re.search(
            r"(?i)(?:Maturity\s+Date|Redemption\s+Date\s*/?\s*Maturity\s+Date)"
            r"\s*[:.]?\s*(\d{1,2}\s+\w+\s+\d{4})",
            self.text,
        )
        if m:
            return m.group(1).strip()

        # Pattern 2 : "Redemption Date / 22 December 2020"
        m = re.search(r"(?i)Redemption\s+Date\s*/\s*(\d{1,2}\s+\w+\s+\d{4})", self.text)
        if m:
            return m.group(1).strip()

        # Pattern 3 : pdfminer table "Maturity Date\n\n04 February 2028"
        m = re.search(
            r"(?i)Maturity\s+Date\s*:?\s*\n+\s*(\d{1,2}\s+\w+\s+\d{4})",
            self.text,
        )
        if m:
            return m.group(1).strip()

        # Pattern 4 : "Maturity Date:\n\n16 August 2027"
        m = re.search(
            r"(?i)Maturity\s+Date\s*:\s*\n+\s*(\d{1,2}\s+\w+\s+\d{4})",
            self.text,
        )
        if m:
            return m.group(1).strip()

        # Pattern 5 : "Redemption Date /\nMaturity Date\n\n22 December 2020"
        m = re.search(
            r"(?i)Redemption\s+Date\s*/\s*\n?\s*Maturity\s+Date\s*\n+\s*"
            r"(\d{1,2}\s+\w+\s+\d{4})",
            self.text,
        )
        if m:
            return m.group(1).strip()

        # Pattern 6 : formats DD/MM/YYYY ou DD.MM.YYYY
        m = re.search(
            r"(?i)Maturity\s+Date\s*[:.]?\s*\n?\s*(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4})",
            self.text,
        )
        if m:
            return m.group(1).strip()

        # Pattern 7 : "Open End" explicite
        if re.search(r"(?i)Expiration\s+Date\s*(?:\(?\s*Expiry\s*\)?)?\s*\n*\s*Open\s+End", self.text):
            return "Open End"

        # Pattern 8 : "no fixed Expiration Date" ou "no fixed Redemption Date"
        if re.search(r"(?i)no\s+fixed\s+(?:Expiration|Redemption)\s+Date", self.text):
            return "Open End"

        # Pattern 9 : "Mini-Future - no fixed Expiration Date"
        if re.search(r"(?i)Mini[\s\-]?Future\s*[\-–]\s*no\s+fixed", self.text):
            return "Open End"

        # Pattern 10 : "Investment Term Up to 5 years"
        m = re.search(r"(?i)Investment\s+Term\s+(?:Up\s+to\s+)?(\d+)\s+years?", self.text)
        if m:
            return f"Up to {m.group(1)} years"

        # Pattern 11 : "Up to X years" standalone (Julius Baer)
        m = re.search(r"(?i)Up\s+to\s+(\d+)\s+years?", self.text[:4000])
        if m:
            return f"Up to {m.group(1)} years"

        return None

    # =========================================================================
    # WORST OR AVERAGE - AMELIORE
    # =========================================================================

    def _extract_worst_or_average(self) -> Optional[str]:
        # Limiter la recherche a la section produit (pas les disclaimers)
        search = self.text[:5000]
        # "WO" dans le titre (Natixis : "su WO AMD")
        if re.search(r"\bWO\b", search):
            return "W"
        # "worst of", "worst-of", "worst performing"
        if re.search(r"(?i)\b(worst[\s\-]?of)\b", search):
            return "W"
        if re.search(r"(?i)(worst[\s\-]?performing)", search):
            return "W"
        # "Linked to worst"
        if re.search(r"(?i)(linked\s+to\s+worst)", search):
            return "W"
        # "Lowest Performing Share"
        if re.search(r"(?i)(lowest\s+performing)", search):
            return "W"
        # "Relevant Underlying" + "lowest performance"
        if re.search(r"(?i)(lowest\s+performance)", search):
            return "W"
        # Average (mais pas "the average level" qui est du disclaimer)
        m = re.search(r"(?i)\b(averaging|basket\s+average|performance\s+moyenne)\b", search)
        if m:
            return "A"
        return None

    # =========================================================================
    # CURRENCY - AMELIORE
    # Gere : "Settlement Currency\n\nCHF" (pdfminer BNP table)
    #        "Redemption Currency\n\nFinancing Level Currency\n\nCHF" (UBS Mini)
    #        "Redemption Currency\n\nUSD" (UBS Autocall - mais avec Quoting Type apres)
    #        "Specified Currency:  EUR" (Natixis inline)
    #        "Currency USD" (simple)
    # =========================================================================

    def _extract_currency(self) -> Optional[str]:
        valid = self.valid_currencies

        # Pattern 1 : inline "Settlement Currency CHF" / "Redemption Currency USD"
        m = re.search(
            r"(?i)(?:Settlement|Redemption|Specified)\s+Currency\s*:?\s+([A-Z]{3})",
            self.text,
        )
        if m and m.group(1) in valid:
            return m.group(1)

        # Pattern 2 : pdfminer table "Settlement Currency\n\nCHF"
        m = re.search(
            r"(?i)(?:Settlement|Redemption)\s+Currency\s*\n+\s*([A-Z]{3})\b",
            self.text,
        )
        if m and m.group(1) in valid:
            return m.group(1)

        # Pattern 3 : pdfminer UBS "Redemption Currency\n\n...Currency\n\nCHF"
        #   (label colonne 1, puis autre label, puis valeur)
        m = re.search(
            r"(?i)(?:Settlement|Redemption)\s+Currency\s*\n+\s*"
            r"(?:Financing\s+Level\s+Currency\s*\n+\s*)?"
            r"([A-Z]{3})\b",
            self.text,
        )
        if m and m.group(1) in valid:
            return m.group(1)

        # Pattern 4 : "Specified Currency: EUR" (Natixis avec espaces)
        m = re.search(r"(?i)Specified\s+Currency\s*:\s*([A-Z]{3})", self.text)
        if m and m.group(1) in valid:
            return m.group(1)

        # Pattern 5 : "Currency\n\nUSD" ou "Currency USD" simple
        m = re.search(r"(?i)(?:^|\n)\s*Currency\s*:?\s*\n?\s*([A-Z]{3})\b", self.text)
        if m and m.group(1) in valid:
            return m.group(1)

        # Pattern 6 : "Denomination\n\nEUR" ou "Denomination EUR 1,000"
        m = re.search(r"(?i)Denomination\s*:?\s*\n?\s*([A-Z]{3})\b", self.text)
        if m and m.group(1) in valid:
            return m.group(1)

        # Pattern 7 : "Issue Price per Certificate\n\nCHF 6.40"
        m = re.search(r"(?i)Issue\s+Price\s+per\s*\n?\s*Certificate\s*\n+\s*([A-Z]{3})\s", self.text)
        if m and m.group(1) in valid:
            return m.group(1)

        # Pattern 8 : currency dans le titre "5 YEAR USD PHOENIX" / "EUR Autocall"
        m = re.search(r"(?i)\b\d+\s+(?:year|ans)\s+([A-Z]{3})\s", self.text[:500])
        if m and m.group(1) in valid:
            return m.group(1)

        return None

    # =========================================================================
    # ISSUER - AMELIORE
    # Gere : "Issuer\n\nUBS AG, London Branch" (pdfminer table)
    #        "Issuer \n\nCREDIT SUISSE INTERNATIONAL..." (CS)
    #        "Issuer:\nNATIXIS STRUCTURED ISSUANCE SA" (Natixis)
    #        "ISSUER: BNP PARIBAS ISSUANCE B.V." (Julius Baer)
    #        Tables BNP ou Issuer est suivi de Guarantor puis la valeur
    # =========================================================================

    def _extract_issuer(self) -> Optional[str]:
        # Strategie 1 : regex directes

        patterns = [
            # "Issuer UBS AG, London Branch"
            r"(?:^|\n)\s*Issuer\s+([A-Z][A-Za-z\s&',\.\(\)\-]+?)(?:,\s*(?:Herengracht|a\s+bank|incorporated|acting|Zurich|London)|(?:\n))",
            # "Issuer\n\nUBS AG, London Branch" (pdfminer table)
            r"(?:^|\n)\s*Issuer\s*\n+\s*([A-Z][A-Za-z\s&',\.\(\)\-]+?)(?:,\s*(?:Herengracht|a\s+bank|incorporated|acting|Zurich|London)|(?:\n))",
            # "Issuer:\nNATIXIS STRUCTURED ISSUANCE SA"
            r"(?:^|\n)\s*Issuer\s*:\s*\n?\s*([A-Z][A-Z\s&',\.\(\)\-]+?)(?:\n)",
            # "ISSUER: BNP PARIBAS ISSUANCE B.V."
            r"ISSUER\s*:\s*([A-Z][A-Z\s&',\.\(\)\-]+?)(?:\n)",
            # "Issuer / Warrant Issuer BNP Paribas..."
            r"Issuer\s*/\s*Warrant\s*Issuer\s*\n?\s*([A-Za-z\s&',\.\(\)\-]+?)(?:\n)",
            # "Issuer \n\nCREDIT SUISSE INTERNATIONAL ("CSi")..."
            r"(?:^|\n)\s*Issuer\s*\n+\s*([A-Z][A-Z\s]+?)(?:\s*\(|,)",
        ]

        for p in patterns:
            m = re.search(p, self.text)
            if m:
                val = m.group(1).strip()
                val = re.sub(r"\s+", " ", val).rstrip(" ,;:-")
                if 3 < len(val) < 80:
                    if not any(fp.lower() in val.lower()
                               for fp in self.issuer_false_positives):
                        # Filtrer les labels qui ne sont pas des noms d'issuer
                        skip_labels = ["Issuer Rating", "Issuer Supervisory",
                                       "Issuer Risk", "Guarantor", "Calculation",
                                       "and Guarantor"]
                        if not any(sl.lower() in val.lower() for sl in skip_labels):
                            return val

        # Strategie 2 : noms connus avec proximite au mot "Issuer"
        best = None
        best_pos = len(self.text)
        for k in self.known_issuers:
            pos = self.text.find(k)
            if pos != -1:
                near_issuer = False
                for im in re.finditer(r"(?i)\bIssuer\b", self.text):
                    if abs(pos - im.start()) < 300:
                        near_issuer = True
                        break
                effective_pos = pos - 5000 if near_issuer else pos
                if effective_pos < best_pos:
                    best_pos = effective_pos
                    best = k
        return best
