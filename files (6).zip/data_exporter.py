# =============================================================================
# modules/data_exporter.py
# Export CSV, Excel (2 feuilles), JSON (avec texte nettoye).
# =============================================================================

import csv
import json
import logging
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)


class DataExporter:

    COLUMNS = ["source_file", "PST_ISIN", "BIL", "CLN",
               "CAPITAL_PROTECTION", "MATURITY", "WORST_OR_AVERAGE",
               "CURRENCY", "ISSUER"]

    def __init__(self, output_dir: str, filename: str = "extraction_results",
                 csv_separator: str = ";", csv_encoding: str = "utf-8-sig"):
        self.output_dir = Path(output_dir)
        self.filename = filename
        self.csv_separator = csv_separator
        self.csv_encoding = csv_encoding
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export_csv(self, records: list) -> Path:
        output_path = self.output_dir / f"{self.filename}.csv"
        with open(output_path, "w", newline="", encoding=self.csv_encoding) as f:
            writer = csv.DictWriter(f, fieldnames=self.COLUMNS,
                                    delimiter=self.csv_separator)
            writer.writeheader()
            for r in records:
                row = {"source_file": r["source_file"]}
                row.update(r["values"])
                writer.writerow(row)
        logger.info(f"CSV exporte : {output_path}")
        return output_path

    def export_json(self, records: list) -> Path:
        output_path = self.output_dir / f"{self.filename}.json"
        data = []
        for r in records:
            data.append({
                "source_file": r["source_file"],
                "text": r.get("text", ""),
                "values": r["values"],
                "underlying_isins": r.get("underlying_isins", []),
            })
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
        logger.info(f"JSON exporte : {output_path}")
        return output_path

    def export_excel(self, records: list) -> Path:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

        output_path = self.output_dir / f"{self.filename}.xlsx"
        wb = Workbook()

        # --- Feuille 1 : Resultats ---
        ws1 = wb.active
        ws1.title = "Resultats"

        hfont = Font(bold=True, color="FFFFFF", size=11)
        hfill = PatternFill(start_color="4A2D7A", end_color="4A2D7A",
                            fill_type="solid")
        border = Border(
            left=Side(style="thin"), right=Side(style="thin"),
            top=Side(style="thin"), bottom=Side(style="thin"),
        )

        for ci, cn in enumerate(self.COLUMNS, 1):
            cell = ws1.cell(row=1, column=ci, value=cn)
            cell.font = hfont
            cell.fill = hfill
            cell.alignment = Alignment(horizontal="center")
            cell.border = border

        for ri, r in enumerate(records, 2):
            row_data = {"source_file": r["source_file"]}
            row_data.update(r["values"])
            for ci, cn in enumerate(self.COLUMNS, 1):
                val = row_data.get(cn, "")
                if val is None:
                    val = ""
                cell = ws1.cell(row=ri, column=ci, value=str(val))
                cell.border = border

        for ci, cn in enumerate(self.COLUMNS, 1):
            ws1.column_dimensions[chr(64 + min(ci, 26))].width = max(len(cn) + 4, 18)

        # --- Feuille 2 : Underlying ISINs ---
        ws2 = wb.create_sheet("Underlying_ISINs")
        und_cols = ["source_file", "PST_ISIN", "UNDERLYING_ISIN"]

        for ci, cn in enumerate(und_cols, 1):
            cell = ws2.cell(row=1, column=ci, value=cn)
            cell.font = hfont
            cell.fill = hfill
            cell.alignment = Alignment(horizontal="center")
            cell.border = border

        ri = 2
        for r in records:
            pst = r["values"].get("PST_ISIN", "")
            for uid in r.get("underlying_isins", []):
                ws2.cell(row=ri, column=1, value=r["source_file"]).border = border
                ws2.cell(row=ri, column=2, value=str(pst or "")).border = border
                ws2.cell(row=ri, column=3, value=uid).border = border
                ri += 1

        for ci in range(1, 4):
            ws2.column_dimensions[chr(64 + ci)].width = 30

        wb.save(output_path)
        logger.info(f"Excel exporte : {output_path}")
        return output_path

    def export_all(self, records: list) -> dict:
        paths = {
            "csv": self.export_csv(records),
            "json": self.export_json(records),
            "excel": self.export_excel(records),
        }
        return paths
