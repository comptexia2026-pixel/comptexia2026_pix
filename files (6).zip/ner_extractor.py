# =============================================================================
# modules/ner_extractor.py
# Extraction de l'ISSUER via spaCy NER pre-entraine (label ORG).
# Pas de fine-tuning : on utilise en_core_web_sm tel quel.
#
# Logique :
#   1. spaCy detecte toutes les entites ORG dans le texte
#   2. On garde celles qui sont proches du mot "Issuer" dans le texte
#   3. On filtre les faux positifs (FINMA, NASDAQ, etc.)
#   4. Si rien trouve -> fallback regex (dans field_extractor.py)
#
# Installation sur votre PC :
#   pip install spacy
#   python -m spacy download en_core_web_sm
# =============================================================================

import re
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Essayer de charger spaCy, sinon on desactive le NER
try:
    import spacy
    _NLP = spacy.load("en_core_web_sm")
    NER_AVAILABLE = True
    logger.info("spaCy NER charge (en_core_web_sm)")
except Exception:
    _NLP = None
    NER_AVAILABLE = False
    logger.info("spaCy non disponible -> fallback regex pour ISSUER")

# Faux positifs : noms d'organisations qui ne sont PAS des issuers
FALSE_POSITIVE_ORGS = {
    "FINMA", "ECB", "FCA", "PRA", "CSSF", "JFSC", "ACPR", "BaFin",
    "CONSOB", "CNMV", "AMF", "SEC", "CFTC", "FSA",
    "NASDAQ", "NYSE", "NYMEX", "CME", "SIX", "SIX SIS",
    "Euroclear", "Clearstream", "Monte Titoli",
    "S&P", "Moody's", "Fitch", "Standard & Poor's",
    "Swiss Federal Act", "Swiss Code of Obligations",
    "European Central Bank", "Bank of New York Mellon",
}


class NERExtractor:

    def __init__(self, text: str):
        self.text = text

    def extract_issuer(self) -> Optional[str]:
        """
        Utilise spaCy pour trouver l'ISSUER.
        Retourne None si spaCy n'est pas disponible ou rien trouve.
        """
        if not NER_AVAILABLE or _NLP is None:
            return None

        # Limiter le texte aux 5000 premiers caracteres (section produit)
        # pour eviter de trouver des ORG dans les disclaimers
        search_text = self.text[:5000]

        doc = _NLP(search_text)

        # Collecter toutes les entites ORG
        org_entities = []
        for ent in doc.ents:
            if ent.label_ == "ORG":
                name = ent.text.strip()
                # Filtrer les faux positifs
                if self._is_false_positive(name):
                    continue
                # Filtrer les noms trop courts ou trop longs
                if len(name) < 3 or len(name) > 80:
                    continue
                org_entities.append({
                    "name": name,
                    "start": ent.start_char,
                    "end": ent.end_char,
                })

        if not org_entities:
            return None

        # Trouver la position du mot "Issuer" le plus pertinent
        # (en debut de ligne, pas dans "Issuer Risk" ou "Issuer Rating")
        issuer_positions = []
        for m in re.finditer(r"(?:^|\n)\s*Issuer\b", search_text):
            # Verifier que ce n'est pas "Issuer Risk", "Issuer Rating", etc.
            after = search_text[m.end():m.end() + 20]
            if not re.match(r"\s*(Risk|Rating|Supervisory|Call|Exercise)", after):
                issuer_positions.append(m.start())

        if not issuer_positions:
            # Pas de label "Issuer" en debut de ligne -> prendre le premier ORG
            return org_entities[0]["name"]

        # Scorer chaque ORG par sa distance au "Issuer" le plus proche
        best_org = None
        best_dist = float("inf")
        for org in org_entities:
            for ip in issuer_positions:
                dist = abs(org["start"] - ip)
                if dist < best_dist:
                    best_dist = dist
                    best_org = org["name"]

        # Ne garder que si la distance est raisonnable (<300 caracteres)
        if best_dist < 300 and best_org:
            return best_org

        return None

    @staticmethod
    def _is_false_positive(name: str) -> bool:
        """Verifie si le nom est un faux positif connu."""
        name_clean = name.strip()
        # Match exact
        if name_clean in FALSE_POSITIVE_ORGS:
            return True
        # Match partiel
        for fp in FALSE_POSITIVE_ORGS:
            if fp.lower() == name_clean.lower():
                return True
        # Patterns a rejeter
        if re.match(r"(?i)(the\s+)?(swiss|european|french|u\.s\.|uk)", name_clean):
            return True
        return False
