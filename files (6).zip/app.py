# =============================================================================
# app.py
# Interface Streamlit pour le Term Sheet Extractor V3.
# Theme BIL violet.
# Usage : streamlit run app.py
# =============================================================================

import streamlit as st
import tempfile
import os
import json
from pathlib import Path

import config
from modules.pdf_extractor import PDFExtractor
from modules.field_extractor import FieldExtractor
from modules.table_extractor import TableExtractor
from modules.ner_extractor import NERExtractor
from modules.data_exporter import DataExporter
from modules.pdf_highlighter import highlight_pdf

# --- Config Streamlit ---
st.set_page_config(page_title="BIL Term Sheet Extractor", page_icon="🏦", layout="wide")

st.markdown("""
<style>
    .stApp { background-color: #f8f6fc; }
    h1, h2, h3 { color: #4A2D7A; }
    .stButton > button { background-color: #4A2D7A; color: white; border-radius: 8px; }
    .stButton > button:hover { background-color: #6B4FA0; }
    .metric-card { background: white; border-radius: 10px; padding: 15px;
                   box-shadow: 0 2px 6px rgba(0,0,0,0.1); margin: 5px 0; }
</style>
""", unsafe_allow_html=True)

st.title("🏦 BIL Term Sheet Extractor V3")
st.markdown("Upload des term sheets PDF → extraction automatique → export Excel")


def process_pdf(filepath):
    """Traite un PDF : Table → NER → Regex → Fusion."""
    pdf_ext = PDFExtractor(str(filepath))
    text = pdf_ext.extract()
    if not text:
        return None

    table_ext = TableExtractor(str(filepath), text)
    table_results = table_ext.extract()

    ner_ext = NERExtractor(text)
    ner_issuer = ner_ext.extract_issuer()

    field_ext = FieldExtractor(
        text=text,
        patterns=config.EXTRACTION_PATTERNS,
        bil_keywords=config.BIL_KEYWORDS,
        known_issuers=config.KNOWN_ISSUERS,
        valid_isin_prefixes=config.VALID_ISIN_PREFIXES,
        valid_currencies=config.VALID_CURRENCIES,
        issuer_false_positives=config.ISSUER_FALSE_POSITIVES,
    )
    regex_results = field_ext.extract_all()

    final_values = regex_results["values"]
    if ner_issuer:
        final_values["ISSUER"] = ner_issuer
    for key, value in table_results.items():
        if value:
            final_values[key] = value

    return {
        "source_file": Path(filepath).name,
        "text": text,
        "values": final_values,
        "underlying_isins": regex_results["underlying_isins"],
    }


# --- Upload ---
uploaded_files = st.file_uploader(
    "Deposez vos PDF ici", type=["pdf"], accept_multiple_files=True
)

if uploaded_files:
    records = []
    progress = st.progress(0)

    for i, uploaded_file in enumerate(uploaded_files):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(uploaded_file.read())
            tmp_path = tmp.name

        result = process_pdf(tmp_path)
        if result:
            result["source_file"] = uploaded_file.name
            result["_tmp_path"] = tmp_path
            records.append(result)

        progress.progress((i + 1) / len(uploaded_files))

    progress.empty()

    if records:
        st.success(f"{len(records)} PDF traites avec succes")

        # --- Tableau des resultats ---
        st.subheader("Resultats")

        cols = ["source_file", "PST_ISIN", "ISSUER", "MATURITY",
                "CURRENCY", "CAPITAL_PROTECTION", "WORST_OR_AVERAGE", "BIL"]
        table_data = []
        for r in records:
            row = {"source_file": r["source_file"]}
            row.update(r["values"])
            table_data.append({k: row.get(k, "") for k in cols})

        st.dataframe(table_data, use_container_width=True)

        # --- Underlying ISINs ---
        und_data = []
        for r in records:
            for uid in r.get("underlying_isins", []):
                und_data.append({
                    "source_file": r["source_file"],
                    "PST_ISIN": r["values"].get("PST_ISIN", ""),
                    "UNDERLYING_ISIN": uid,
                })
        if und_data:
            st.subheader("Underlying ISINs")
            st.dataframe(und_data, use_container_width=True)

        # --- Export Excel ---
        with tempfile.TemporaryDirectory() as tmpdir:
            exporter = DataExporter(tmpdir, "extraction_results")
            excel_path = exporter.export_excel(records)

            with open(excel_path, "rb") as f:
                st.download_button(
                    "📥 Telecharger Excel",
                    data=f.read(),
                    file_name="extraction_results.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )

        # --- Detail par PDF ---
        st.subheader("Detail par document")
        for r in records:
            with st.expander(f"📄 {r['source_file']}"):
                col1, col2 = st.columns(2)
                with col1:
                    for field in ["PST_ISIN", "ISSUER", "MATURITY", "CURRENCY"]:
                        val = r["values"].get(field, "")
                        st.markdown(f"**{field}:** {val}")
                with col2:
                    for field in ["CAPITAL_PROTECTION", "WORST_OR_AVERAGE", "BIL", "CLN"]:
                        val = r["values"].get(field, "")
                        st.markdown(f"**{field}:** {val}")

                if r.get("underlying_isins"):
                    st.markdown(f"**Underlyings:** {', '.join(r['underlying_isins'])}")

                # Texte converti (premiers 500 chars)
                st.text_area("Texte extrait (debut)", r["text"][:500], height=150,
                             key=f"text_{r['source_file']}")

        # Nettoyage des fichiers temporaires
        for r in records:
            tmp_path = r.get("_tmp_path")
            if tmp_path and os.path.exists(tmp_path):
                os.unlink(tmp_path)
